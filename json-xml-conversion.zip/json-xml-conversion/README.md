Requirements
------------
This project required java1.8 or higher
The project makes use of gradle and uses the gradle wrapper , which means don't needs to gradle installed.

Build the project
-----------------
./gradlew build

Run the Project
---------------
java -jar build/libs/json-xml-conversion.jar <JsonFilePath> <XMLFile>

Note
----
Not created any test file for this.
But I know Mocktio and Power & Easy Mock.
And strategy pattern used to implement this xml conversion.
And google simple-json library used for parsing the json file.